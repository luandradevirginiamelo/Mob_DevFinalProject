package com.example.finalproject_mobdev.data

data class Pub(
    val name: String,
    val craicScore: Int, // Craic score from 1 to 5
    val comment: String
)